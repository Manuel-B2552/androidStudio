package com.manuel.spinner

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private lateinit var spinner: Spinner

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.my_spinner)
        val exitButton: Button = findViewById(R.id.exit_button)
        val button: Button = findViewById(R.id.button2) // Mover esta línea aquí

        val options = arrayOf("Chile", "Venezuela", "Brasil", "España")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, options)

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                Toast.makeText(this@MainActivity, "Seleccionaste: $selectedItem", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Do nothing
            }
        }

        // Configurar el OnClickListener del botón para iniciar la segunda actividad
        button.setOnClickListener {
            // Iniciar la segunda actividad
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }

        // Configurar el botón de salir
        exitButton.setOnClickListener {
            finish() // Esto cerrará la actividad
        }
    }
}
