package com.manuel.spinner

import android.annotation.SuppressLint
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val exitButton: Button = findViewById(R.id.exit_button)

        // Configurar el botón de salir
        exitButton.setOnClickListener {
            finish() // Esto cerrará la actividad
        }
    }
}
